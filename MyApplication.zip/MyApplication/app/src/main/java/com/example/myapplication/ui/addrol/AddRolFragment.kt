package com.example.myapplication.ui.addrol

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController

import com.example.myapplication.R
import com.example.myapplication.database.ZeventDataBase
import com.example.myapplication.databinding.AddRolFragmentBinding
import com.example.myapplication.databinding.FragmentAddBinding

class AddRolFragment : Fragment() {
    private lateinit var addRolViewModel: AddRolViewModel
    private lateinit var binding: AddRolFragmentBinding
    private lateinit var addRolViewModelFactory: AddRolViewModelFactory

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        //val root = inflater.inflate(R.layout.fragment_add, container, false)


        binding = DataBindingUtil.inflate(inflater, R.layout.add_rol_fragment, container, false)




        setHasOptionsMenu(true)

        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        binding.lifecycleOwner = this
        val application = requireNotNull(this.activity).application
        val dataSource = ZeventDataBase.getInstance(application).zeventDao
        addRolViewModelFactory = AddRolViewModelFactory(dataSource)
        addRolViewModel =
            ViewModelProvider(this, addRolViewModelFactory).get(AddRolViewModel::class.java)
        binding.addRolViewModel = addRolViewModel
        val seek= binding.seekBar

        seek?.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seek: SeekBar,
                                           progress: Int, fromUser: Boolean) {
                // write custom code for progress is changed
            }

            override fun onStartTrackingTouch(seek: SeekBar) {
                // write custom code for progress is started
            }

            override fun onStopTrackingTouch(seek: SeekBar) {
                val value = (seek.progress)/10

                binding.textView.text=value.toString()
                // write custom code for progress is stopped

            }
        })





    binding.saverol.setOnClickListener { v: View ->


            addRolViewModel.insertRol()
        }


    }
}
