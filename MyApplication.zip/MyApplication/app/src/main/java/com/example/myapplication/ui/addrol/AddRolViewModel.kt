package com.example.myapplication.ui.addrol

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.myapplication.database.Register
import com.example.myapplication.database.Rol
import com.example.myapplication.database.ZeventDao
import kotlinx.coroutines.*

class AddRolViewModel (val database: ZeventDao): ViewModel() {

    val rols=MutableLiveData<String>()
    val desc=MutableLiveData<String>()
    val rate=MutableLiveData<String>()
    private val viewModelJob = Job()


    private val uiScope = CoroutineScope(Dispatchers.Main + viewModelJob)
    fun insertRol() {
        uiScope.launch {
            insert()
        }
    }

    private suspend fun insert(){
        withContext(Dispatchers.IO) {
            database.insertRol(Rol(rolName = rols.value?:"",rolDesc = desc.value?:"",rate = rate.value?:""))
        }
    }

    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }




}
