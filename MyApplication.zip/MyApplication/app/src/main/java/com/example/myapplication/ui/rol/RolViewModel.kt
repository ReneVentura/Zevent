package com.example.myapplication.ui.rol

import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.example.myapplication.database.Rol
import com.example.myapplication.database.ZeventDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job

class RolViewModel(val database: ZeventDao): ViewModel() {
    private var viewModelJob= Job()
    private val uiScope= CoroutineScope(Dispatchers.Main+viewModelJob)
    private var allRol= database.getAllRol()


    val rols= Transformations.map(allRol){
        getAll(it)
    }


    private fun getAll(names:List<Rol>):String {


        val allRegist= StringBuilder()


        for (name in names)
            allRegist.append("Rol: ${name.rolName}\nDescripcion: ${name.rolDesc}\nRol: ${name.rate}\n\n\n")

        return allRegist.toString()



    }

    override fun onCleared(){

        super.onCleared()
        viewModelJob.cancel()
    }
}


