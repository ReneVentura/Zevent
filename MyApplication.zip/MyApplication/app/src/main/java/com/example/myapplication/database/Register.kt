package com.example.myapplication.database

import androidx.databinding.DataBindingUtil
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.myapplication.R
import com.example.myapplication.databinding.FragmentRegisterBinding


@Entity(tableName= "register_table")


data class Register (

    @PrimaryKey(autoGenerate=true)
    var registerId: Long = 0L,
    @ColumnInfo(name= "name")
    var name : String ="",
    @ColumnInfo(name = "number")
    var number :String="",
    @ColumnInfo(name="mail")
    var mail : String="",
    @ColumnInfo(name="rol")
    var rol:String=""

)