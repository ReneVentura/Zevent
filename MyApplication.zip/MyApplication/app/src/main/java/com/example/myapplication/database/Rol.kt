package com.example.myapplication.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rol_table")

data class Rol (

    @PrimaryKey(autoGenerate=true)
    var rolId: Long = 0L,
    @ColumnInfo(name= "rol_name")
    var rolName : String ="",
    @ColumnInfo(name = "rol_desc")
    var rolDesc :String="",
    @ColumnInfo(name="rate")
    var rate : String=""

)