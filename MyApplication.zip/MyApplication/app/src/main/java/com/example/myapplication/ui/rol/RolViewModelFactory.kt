package com.example.myapplication.ui.rol

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.database.ZeventDao

class RolViewModelFactory (private val database: ZeventDao): ViewModelProvider.Factory{
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(RolViewModel::class.java))
            return RolViewModel(database) as T
        throw IllegalArgumentException("Unknown ViewModel Class")

}
}