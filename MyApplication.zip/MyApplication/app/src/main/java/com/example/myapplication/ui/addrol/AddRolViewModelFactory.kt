package com.example.myapplication.ui.addrol

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.database.ZeventDao

class AddRolViewModelFactory (private val database: ZeventDao): ViewModelProvider.Factory{
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(AddRolViewModel::class.java))
            return AddRolViewModel(database) as T
        throw IllegalArgumentException("Unknown ViewModel Class")

    }

}