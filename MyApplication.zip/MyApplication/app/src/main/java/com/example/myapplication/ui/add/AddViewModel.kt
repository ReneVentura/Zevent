package com.example.myapplication.ui.add

import android.app.Application
import androidx.lifecycle.*
import com.example.myapplication.database.Register
import com.example.myapplication.database.Rol
import com.example.myapplication.database.ZeventDao
import kotlinx.coroutines.*
import java.lang.StringBuilder

public class AddViewModel(val database:ZeventDao): ViewModel(){
    val name = MutableLiveData<String>()
    val number = MutableLiveData<String>()
    val mail = MutableLiveData<String>()
    val role = MutableLiveData<String>()
    private val allRol= database.getAllRol()
    val rol= Transformations.map(allRol){
        getRol(it)
    }
    private val viewModelJob = Job()

    private val uiScope = CoroutineScope(Dispatchers.Main + viewModelJob)
    fun insertRegister() {
        uiScope.launch {
            insert()
        }
    }

    private suspend fun insert(){
        withContext(Dispatchers.IO) {
            database.insert(Register(name = name.value ?:"",number = number.value?:"",mail = mail.value?:"",rol = role.value?:""))
        }
    }

    private fun getRol(rols:List<Rol>):String{
        val allRols=StringBuilder()

        for(rol in rols){

            allRols.append("${rol.rolName}, ")
        }

        return allRols.toString()


    }

    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }



} /*(val dataBase: ZeventDao, application: Application): AndroidViewModel(application){

    val number= MutableLiveData<String>()
    val mail=MutableLiveData<String>()

    private val viewModelJob = Job()

    private val uiScope = CoroutineScope(Dispatchers.Main + viewModelJob)

    fun insertRegister() {
        uiScope.launch {
            insert()
        }
    }

    private suspend fun insert(){
        withContext(Dispatchers.IO) {
            dataBase.insert(Register(name = name.value ?: "",number = number.value?:"",mail = mail.value?:""))
        }
    }

    override fun onCleared() {
        super.onCleared()
        viewModelJob.cancel()
    }*/



